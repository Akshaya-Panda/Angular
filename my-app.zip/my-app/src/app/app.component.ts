import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet } from '@angular/router';
import { SecondComponent } from './second/second.component';
import { ThirdComponent } from './third/third.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { ContentComponent } from './content/content.component';
import { DataComponent } from './data/data.component';
DataComponent
@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet,SecondComponent,ThirdComponent,SidebarComponent,ContentComponent,DataComponent],
  templateUrl: './app.component.html',
 // template:'<div> <p> Welcome UI</p> </div>',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'my-app';
  name='Akshaya'
  cube(x:number)
  {
    return(x*x*x)
  }
}
