import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { routes } from '../app.routes';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.css'
})
export class SidebarComponent {
  
disp()
{
  (document.getElementById('abc')as HTMLElement).innerHTML=
  "<font color='red' size='22'>Welcome Home</font>"
}
}