import { TestBed } from '@angular/core/testing';

import { MyswerviceService } from './myswervice.service';

describe('MyswerviceService', () => {
  let service: MyswerviceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MyswerviceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
