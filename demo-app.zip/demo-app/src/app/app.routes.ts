import { Routes } from '@angular/router';
import { EmpComponent } from './emp/emp.component';
import { ThirdComponent } from './third/third.component';


export const routes: Routes = [{path:'emp',component:EmpComponent},
                                {path:'third',component:ThirdComponent}];
