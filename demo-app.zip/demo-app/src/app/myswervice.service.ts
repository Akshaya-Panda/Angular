import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class MyswerviceService {

  constructor() {
  
   }
   add(x:number,y:number)
   {
return x+y;
   }
}
