import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';
import { routes } from '../app.routes';

@Component({
  selector: 'app-second',
  standalone: true,
  imports: [RouterModule],
  templateUrl: './second.component.html',
  styleUrl: './second.component.css'
})
export class SecondComponent {
// constructor()
// {
//   RouterModule.forRoot(routes)
// }
}
