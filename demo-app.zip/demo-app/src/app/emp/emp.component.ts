import { CommonModule, DatePipe, UpperCasePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { routes } from '../app.routes';
import { MyswerviceService } from '../myswervice.service';
import { MyPipePipe } from '../my-pipe.pipe';

@Component({
  selector: 'app-emp',
  standalone: true,
  imports: [CommonModule,UpperCasePipe,DatePipe,MyPipePipe,FormsModule],
  providers:[MyswerviceService],
  templateUrl: './emp.component.html',
  styleUrl: './emp.component.css'
})
export class EmpComponent{
  route:Router=new Router();
  
  constructor(public mserv:MyswerviceService)
  {
   // RouterModule.forRoot(routes)
  }
   d=new Date();
  employee=[{id:101,name:'Karthik',salary:55000},
          {id:102,name:'Sagar',salary:57000},
          {id:103,name:'Vikram',salary:59000}]
          func(data:any)
          {
            alert(JSON.stringify(data))
          }
          myfunc(data:any)
          {
            if((data.user.value=='AD-001')&&(data.pass.value=='AD-001'))
            {
             // (document.getElementById('abc')as HTMLElement).innerHTML='Valid Username and Password'
            this.route.navigateByUrl('third')
            }
            else{
              (document.getElementById('abc')as HTMLElement).innerHTML='Invalid Username and Password'
            }
          }
        }
